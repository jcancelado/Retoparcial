"""Capa de datos para integraciones externas (Firebase, etc.)."""


